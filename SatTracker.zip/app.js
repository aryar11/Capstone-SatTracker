const menu = document.querySelector('mobile-menu');
const menlink = documents.querySelector('.navbar_menu');

menu.addEventListener('click', function(){
    menu.classList.toggle('is-active');
    menuLinks.classList.toggle('active');
})
