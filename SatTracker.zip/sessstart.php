<?php
//redirect to tool
session_start();

header("location: tracker.html");

?>