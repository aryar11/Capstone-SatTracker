orbital_objects
===============

Messing around with Google's WebGL globe, visualizing satellite positions.

For more information, see [this blog post](http://alexras.info/blog/2013/11/30/visualizing-satellites-and-space-debris.html).
